# 학습 끝난 모델로 사진 한 장 테스트해보는 스크립트
# 사용법: python predict.py 테스트할사진.jpg

import sys

from ultralytics import YOLO

WEIGHTS_PATH = "runs/plate_detect/weights/best.pt"


def main():
    if len(sys.argv) < 2:
        print("사용법: python predict.py 사진경로.jpg")
        return

    image_path = sys.argv[1]
    model = YOLO(WEIGHTS_PATH)

    results = model.predict(source=image_path, conf=0.4, save=True)

    for r in results:
        boxes = r.boxes
        print(f"번호판 후보 {len(boxes)}개 검출됨")
        for box in boxes:
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            conf = float(box.conf[0])
            print(f"  위치: ({x1:.0f}, {y1:.0f}) ~ ({x2:.0f}, {y2:.0f}) / 신뢰도: {conf:.2f}")

    print("결과 이미지는 runs/detect/predict 폴더에 저장됨")


if __name__ == "__main__":
    main()
