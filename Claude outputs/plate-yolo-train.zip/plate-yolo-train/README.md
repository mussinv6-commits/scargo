# 번호판 위치 탐지 모델 학습

지금 plate-api는 easyocr로 사진 전체를 다 읽고 있어서 느리고 엉뚱한 글자까지 잡아냄.
이 프로젝트는 "번호판이 사진 어디쯤 있는지"만 먼저 찾아내는 모델을 직접 학습시켜서,
나중에 그 부분만 잘라서 OCR을 돌리는 방식으로 개선하기 위한 것.

## 1. 폴더 구조

```
plate-yolo-train/
├── dataset/
│   ├── images/
│   │   ├── train/   ← 학습용 사진 (.jpg)
│   │   └── val/     ← 검증용 사진 (.jpg)
│   └── labels/
│       ├── train/   ← 학습용 사진과 이름이 같은 라벨 .txt
│       └── val/
├── dataset.yaml
├── train.py
├── predict.py
└── requirements.txt
```

사진 파일명과 라벨 파일명은 확장자만 다르고 나머지는 똑같아야 함
(예: `truck001.jpg` ↔ `truck001.txt`).

## 2. 라벨링 (제일 중요한 단계)

찍어온 사진에 "번호판이 어디 있는지" 박스를 직접 그려줘야 모델이 학습할 수 있음.
직접 텍스트 파일을 쓰는 건 비효율적이니 아래 둘 중 하나를 추천:

**추천: Roboflow (roboflow.com, 무료, 웹에서 마우스로 박스만 그리면 됨)**
1. 회원가입 후 새 프로젝트 생성 (Object Detection)
2. 찍어둔 사진들 업로드
3. 사진마다 번호판 위치에 박스 그리고 클래스 이름 `plate`로 지정
4. 어느 정도 라벨링했으면 "Generate" → train/val 비율 나누기 (80/20 정도)
5. Export 할 때 포맷을 **YOLOv8**로 선택 → zip 다운로드
6. 압축 풀면 `images/`, `labels/` 폴더가 이미 train/val로 나뉘어서 나옴 → 그대로 `dataset/` 안에 덮어쓰기

**대안: labelImg (설치형 프로그램)**
- `pip install labelImg` 후 `labelImg` 실행
- 저장 포맷을 YOLO로 설정하고 박스 그리면 `.txt` 라벨이 자동 생성됨
- 이 경우엔 train/val 폴더 나누는 것도 직접 해야 함 (사진 8:2 정도로 수동 분배)

번호판 사진은 최소 100장 이상은 있어야 어느 정도 쓸만하게 학습됨.
처음엔 적은 장수로 일단 파이프라인이 도는지만 확인하고, 사진을 더 모으면서 재학습하는 식으로 진행하면 됨.

## 3. 설치

```
pip install -r requirements.txt
```

(Anaconda Prompt에서 작업하던 환경이면 거기서 그대로 설치하면 됨. ultralytics가 torch까지 같이 설치하기 때문에 시간이 좀 걸림)

## 4. 학습 실행

```
python train.py
```

끝나면 `runs/plate_detect/weights/best.pt`가 학습된 가중치 파일.

## 5. 결과 테스트

```
python predict.py 테스트할사진.jpg
```

번호판 위치와 신뢰도가 출력되고, 박스 그려진 결과 이미지는 `runs/detect/predict`에 저장됨.

## CPU/GPU 참고

이전에 easyocr 돌릴 때 로그에 "Using CPU"가 떴던 걸 보면 노트북에 GPU가 없는 것 같음.
YOLO 학습은 CPU로도 되긴 하지만 GPU보다 훨씬 오래 걸림 (사진 수/에폭에 따라 몇 배 이상 차이).

사진이 많아지고 학습이 너무 느리면 **Google Colab** 사용을 추천:
- colab.research.google.com에서 새 노트북 생성
- 상단 메뉴 런타임 → 런타임 유형 변경 → GPU 선택
- 이 폴더의 `dataset/`, `dataset.yaml`, `train.py`를 업로드하고 `!pip install ultralytics` 후 `!python train.py` 실행
- 무료로 GPU를 쓸 수 있어서 훨씬 빠름

## 다음 단계 (참고)

학습이 잘 되면 `plate-api/app/ocr.py`에서 지금처럼 사진 전체를 easyocr에 넣는 대신,
1) 이 YOLO 모델로 먼저 번호판 위치(박스)만 찾고
2) 그 박스 부분만 잘라서(crop) easyocr에 넣는 구조로 바꾸면
속도도 빨라지고 엉뚱한 글자를 잘못 잡는 것도 줄어듦.
