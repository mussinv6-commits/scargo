# 번호판 위치 탐지 모델 학습
# easyocr은 사진 전체를 다 읽어서 느리고 엉뚱한 글자도 잡아내니까,
# 번호판이 어디 있는지부터 먼저 찾아내는 모델을 따로 학습시켜서 앞단에 붙이는 용도

from ultralytics import YOLO


def main():
    # yolov8n(가장 작은 버전)의 사전학습 가중치에서 시작 - 처음부터 학습시키면 데이터가 훨씬 많이 필요함
    model = YOLO("yolov8n.pt")

    model.train(
        data="dataset.yaml",
        epochs=50,
        imgsz=640,
        batch=8,
        patience=15,        # 15에폭 동안 성능이 안 좋아지면 알아서 멈춤 (과적합 방지)
        project="runs",
        name="plate_detect",
    )

    # 끝나면 runs/plate_detect/weights/best.pt 에 가장 성능 좋은 가중치가 저장됨
    print("학습 완료 -> runs/plate_detect/weights/best.pt 확인")


if __name__ == "__main__":
    main()
